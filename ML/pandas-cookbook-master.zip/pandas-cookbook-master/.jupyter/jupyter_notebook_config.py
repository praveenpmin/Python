c.MappingKernelManager.default_kernel_name = 'python2'
